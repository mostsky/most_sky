#!/system/bin/sh

# 停止服务
killall /data/adb/service.d/shamkio.sh

sleep 1

rm -rf /data/adb/service.d/shamkio.sh




