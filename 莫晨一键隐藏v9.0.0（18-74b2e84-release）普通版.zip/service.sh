#!/system/bin/sh
MODDIR=${0%/*}

while [ "$(getprop sys.boot_completed)" != "1" ]; do
  sleep 3
done

# settings put global adb_enabled 0
# settings put global development_settings_enabled 0
# resetprop ro.debuggable 0

#解决log泄漏
resetprop -n persist.logd.size ""
resetprop -n persist.logd.size.crash ""
resetprop -n persist.logd.size.main ""
resetprop -n persist.log.tag ""

#修复数据未加密
resetprop ro.crypto.state encrypted

#尝试通过bl弱检测
resetprop ro.boot.flash.locked 1
resetprop ro.boot.verifiedbootstate green
resetprop ro.secureboot.lockstate locked
resetprop ro.boot.vbmeta.device_state locked
resetprop -n init.svc.adbd stopped
resetprop -w sys.boot_completed 0






# 删除 模块文件夹
rm -rf /data/adb/modules/most_sky/apk
rm -rf /data/adb/modules/most_sky/Calss

# 删除 TWRP 文件夹，清理残留
rm -rf /data/media/0/TWRP
rm -r /storage/emulated/0/TWRP

rm -rf /data/local/tmp/shizuku/
rm -rf /data/local/tmp/shizuku_starter
rm -f /data/local/tmp/shizuku/
rm -f /data/local/tmp/shizuku_starter

#删除 MT2 文件夹
rm -rf //storage/emulated/0/MT2




# 开机后自动禁用 DM-Verity 和启动校检
avbctl disable-verity --force
avbctl disable-verification --force



sh /data/adb/modules/most_sky/删除target游戏包名.sh


#!/system/bin/sh

# 目标配置文件路径
CONFIG_FILE="/data/data/com.tsng.hidemyapplist/files/config.json"

# 隐藏应用列表配置内容
NEW_CONFIG='{"configVersion":93,"detailLog":false,"maxLogSize":512,"forceMountData":true,"disableActivityLaunchProtection":false,"altAppDataIsolation":false,"altVoldAppDataIsolation":false,"skipSystemAppDataIsolation":true,"packageQueryWorkaround":false,"templates":{"莫晨隐藏环境v4.0.0普通版":{"isWhitelist":false,"appList":["com.feilun.main","Han.GJZS","tmgp.atlas.toolbox","com.accessibilitymanager","web1n.stopapp","com.daxiaamu.op7mutools","com.surcumference.fingerprintpay","li.songe.gkd","org.frknkrc44.hma_oss","com.guoshi.httpcanary","com.github.capntrips.kernelflasher","io.github.a13e300.ksuwebui","org.telegram.messenger.web","com.omarea.vtools","chunqiu.safe.detector","com.dijia1124.plusplusbattery","wu.keyChain.test","hbjx.igljd.dmkdgpl","ufm.itdqb.gzoerquvuLxlmOlo","gdo.pgqhiu.blcysrb.xdjcgc.ojftshx","com.time.tools","org.akanework.checker","ch.nlzuxwqr.xadwutv","com.shinegirls.RemoveSharePopup","com.victwonowtmk.tool","icu.nullptr.applistdetector","com.youhu.laifu","com.studio.duckdetector","com.fkjc.zcro","net.fusionapp","com.mt2.peonyking","me.garfieldhan.holmes","com.zhenxi.hunter","just.trust.me","com.lingqing.detector","luna.safe.luna","io.github.huskydg.memorydetector","io.github.vvb2060.mahoshojo","bin.mt.plus","bin.mt.termex","com.reveny.nativecheck","icu.nullptr.nativetest","com.github.dan.NoStorageRestrict","com.godevelopers.OprekCek","com.byxiaorun.detector","moe.shizuku.privileged.api","com.sukisu.ultra","com.virb3.trustmealready"]}},"settingsTemplates":{"莫晨环境设置v3.0.0普通版":{"settingsList":[{"name":"android_id","value":"0ae75095eec6b4ca","database":"secure"}]},"普通版没有vip版强":{"settingsList":[]}},"scope":{"chunqiu.safe.detector":{"useWhitelist":false,"excludeSystemApps":true,"hideInstallationSource":true,"hideSystemInstallationSource":true,"excludeTargetInstallationSource":true,"invertActivityLaunchProtection":true,"excludeVoldIsolation":false,"applyTemplates":["莫晨隐藏环境v4.0.0普通版"],"applyPresets":["detector_apps"],"applySettingTemplates":["莫晨环境设置v3.0.0普通版"],"applySettingsPresets":["accessibility","dev_options"],"extraAppList":[]},"com.tencent.tmgp.pubgmhd":{"useWhitelist":false,"excludeSystemApps":true,"hideInstallationSource":true,"hideSystemInstallationSource":true,"excludeTargetInstallationSource":true,"invertActivityLaunchProtection":true,"excludeVoldIsolation":false,"applyTemplates":["莫晨隐藏环境v4.0.0普通版"],"applyPresets":["detector_apps"],"applySettingTemplates":["莫晨环境设置v3.0.0普通版"],"applySettingsPresets":["accessibility","dev_options"],"extraAppList":[]},"com.tencent.jkchess":{"useWhitelist":false,"excludeSystemApps":true,"hideInstallationSource":true,"hideSystemInstallationSource":true,"excludeTargetInstallationSource":true,"invertActivityLaunchProtection":true,"excludeVoldIsolation":false,"applyTemplates":["莫晨隐藏环境v4.0.0普通版"],"applyPresets":["custom_rom"],"applySettingTemplates":["莫晨环境设置v3.0.0普通版"],"applySettingsPresets":["accessibility","dev_options"],"extraAppList":[]},"com.bajiaostar.findjob":{"useWhitelist":false,"excludeSystemApps":true,"hideInstallationSource":true,"hideSystemInstallationSource":true,"excludeTargetInstallationSource":true,"invertActivityLaunchProtection":true,"excludeVoldIsolation":false,"applyTemplates":["莫晨隐藏环境v4.0.0普通版"],"applyPresets":["custom_rom"],"applySettingTemplates":["莫晨环境设置v3.0.0普通版"],"applySettingsPresets":["accessibility","dev_options"],"extraAppList":[]},"com.surcumference.fingerprintpay":{"useWhitelist":false,"excludeSystemApps":true,"hideInstallationSource":true,"hideSystemInstallationSource":true,"excludeTargetInstallationSource":true,"invertActivityLaunchProtection":true,"excludeVoldIsolation":false,"applyTemplates":["莫晨隐藏环境v4.0.0普通版"],"applyPresets":["xposed"],"applySettingTemplates":["莫晨环境设置v3.0.0普通版"],"applySettingsPresets":["accessibility","dev_options"],"extraAppList":[]},"icu.nullptr.applistdetector":{"useWhitelist":false,"excludeSystemApps":true,"hideInstallationSource":true,"hideSystemInstallationSource":true,"excludeTargetInstallationSource":true,"invertActivityLaunchProtection":true,"excludeVoldIsolation":false,"applyTemplates":["莫晨隐藏环境v4.0.0普通版"],"applyPresets":["detector_apps"],"applySettingTemplates":["莫晨环境设置v3.0.0普通版"],"applySettingsPresets":["accessibility","dev_options"],"extraAppList":[]},"com.youhu.laifu":{"useWhitelist":false,"excludeSystemApps":true,"hideInstallationSource":true,"hideSystemInstallationSource":true,"excludeTargetInstallationSource":true,"invertActivityLaunchProtection":true,"excludeVoldIsolation":false,"applyTemplates":["莫晨隐藏环境v4.0.0普通版"],"applyPresets":["detector_apps","sus_apps"],"applySettingTemplates":["莫晨环境设置v3.0.0普通版"],"applySettingsPresets":["accessibility","dev_options"],"extraAppList":[]},"li.songe.gkd":{"useWhitelist":false,"excludeSystemApps":true,"hideInstallationSource":true,"hideSystemInstallationSource":true,"excludeTargetInstallationSource":true,"invertActivityLaunchProtection":false,"excludeVoldIsolation":false,"applyTemplates":["莫晨隐藏环境v4.0.0普通版"],"applyPresets":["root_apps"],"applySettingTemplates":["莫晨环境设置v3.0.0普通版"],"applySettingsPresets":["accessibility","dev_options"],"extraAppList":[]},"me.garfieldhan.holmes":{"useWhitelist":false,"excludeSystemApps":true,"hideInstallationSource":true,"hideSystemInstallationSource":true,"excludeTargetInstallationSource":true,"invertActivityLaunchProtection":false,"excludeVoldIsolation":false,"applyTemplates":["莫晨隐藏环境v4.0.0普通版"],"applyPresets":["detector_apps","sus_apps"],"applySettingTemplates":["莫晨环境设置v3.0.0普通版"],"applySettingsPresets":["accessibility","dev_options"],"extraAppList":[]},"com.zhenxi.hunter":{"useWhitelist":false,"excludeSystemApps":true,"hideInstallationSource":true,"hideSystemInstallationSource":true,"excludeTargetInstallationSource":true,"invertActivityLaunchProtection":false,"excludeVoldIsolation":false,"applyTemplates":["莫晨隐藏环境v4.0.0普通版"],"applyPresets":["detector_apps"],"applySettingTemplates":["莫晨环境设置v3.0.0普通版"],"applySettingsPresets":["accessibility","dev_options"],"extraAppList":[]},"luna.safe.luna":{"useWhitelist":false,"excludeSystemApps":true,"hideInstallationSource":true,"hideSystemInstallationSource":true,"excludeTargetInstallationSource":true,"invertActivityLaunchProtection":false,"excludeVoldIsolation":false,"applyTemplates":["莫晨隐藏环境v4.0.0普通版"],"applyPresets":["detector_apps"],"applySettingTemplates":["莫晨环境设置v3.0.0普通版"],"applySettingsPresets":["accessibility","dev_options"],"extraAppList":[]},"com.lingqing.detector":{"useWhitelist":false,"excludeSystemApps":true,"hideInstallationSource":true,"hideSystemInstallationSource":true,"excludeTargetInstallationSource":true,"invertActivityLaunchProtection":false,"excludeVoldIsolation":false,"applyTemplates":["莫晨隐藏环境v4.0.0普通版"],"applyPresets":["detector_apps"],"applySettingTemplates":["莫晨环境设置v3.0.0普通版"],"applySettingsPresets":["accessibility","dev_options"],"extraAppList":[]},"io.github.huskydg.memorydetector":{"useWhitelist":false,"excludeSystemApps":true,"hideInstallationSource":true,"hideSystemInstallationSource":true,"excludeTargetInstallationSource":true,"invertActivityLaunchProtection":false,"excludeVoldIsolation":false,"applyTemplates":["莫晨隐藏环境v4.0.0普通版"],"applyPresets":["detector_apps"],"applySettingTemplates":["莫晨环境设置v3.0.0普通版"],"applySettingsPresets":["accessibility","dev_options"],"extraAppList":[]},"io.github.vvb2060.mahoshojo":{"useWhitelist":false,"excludeSystemApps":true,"hideInstallationSource":true,"hideSystemInstallationSource":true,"excludeTargetInstallationSource":true,"invertActivityLaunchProtection":false,"excludeVoldIsolation":false,"applyTemplates":["莫晨隐藏环境v4.0.0普通版"],"applyPresets":["detector_apps"],"applySettingTemplates":["莫晨环境设置v3.0.0普通版"],"applySettingsPresets":["accessibility","dev_options"],"extraAppList":[]},"com.reveny.nativecheck":{"useWhitelist":false,"excludeSystemApps":true,"hideInstallationSource":true,"hideSystemInstallationSource":true,"excludeTargetInstallationSource":true,"invertActivityLaunchProtection":false,"excludeVoldIsolation":false,"applyTemplates":["莫晨隐藏环境v4.0.0普通版"],"applyPresets":["detector_apps"],"applySettingTemplates":["莫晨环境设置v3.0.0普通版"],"applySettingsPresets":["accessibility","dev_options"],"extraAppList":[]},"icu.nullptr.nativetest":{"useWhitelist":false,"excludeSystemApps":true,"hideInstallationSource":true,"hideSystemInstallationSource":true,"excludeTargetInstallationSource":true,"invertActivityLaunchProtection":false,"excludeVoldIsolation":false,"applyTemplates":["莫晨隐藏环境v4.0.0普通版"],"applyPresets":["detector_apps"],"applySettingTemplates":["莫晨环境设置v3.0.0普通版"],"applySettingsPresets":["accessibility","dev_options"],"extraAppList":[]},"com.MobileTicket":{"useWhitelist":false,"excludeSystemApps":true,"hideInstallationSource":true,"hideSystemInstallationSource":true,"excludeTargetInstallationSource":true,"invertActivityLaunchProtection":false,"excludeVoldIsolation":false,"applyTemplates":["莫晨隐藏环境v4.0.0普通版"],"applyPresets":["custom_rom"],"applySettingTemplates":["莫晨环境设置v3.0.0普通版"],"applySettingsPresets":["accessibility","dev_options"],"extraAppList":[]},"com.yitong.mbank.psbc":{"useWhitelist":false,"excludeSystemApps":true,"hideInstallationSource":true,"hideSystemInstallationSource":true,"excludeTargetInstallationSource":true,"invertActivityLaunchProtection":false,"excludeVoldIsolation":false,"applyTemplates":["莫晨隐藏环境v4.0.0普通版"],"applyPresets":["custom_rom"],"applySettingTemplates":["莫晨环境设置v3.0.0普通版"],"applySettingsPresets":["accessibility","dev_options"],"extraAppList":[]},"com.eg.android.AlipayGphone":{"useWhitelist":false,"excludeSystemApps":true,"hideInstallationSource":true,"hideSystemInstallationSource":true,"excludeTargetInstallationSource":true,"invertActivityLaunchProtection":false,"excludeVoldIsolation":false,"applyTemplates":["莫晨隐藏环境v4.0.0普通版"],"applyPresets":["custom_rom"],"applySettingTemplates":["莫晨环境设置v3.0.0普通版"],"applySettingsPresets":["accessibility","dev_options"],"extraAppList":[]},"com.sankuai.meituan":{"useWhitelist":false,"excludeSystemApps":true,"hideInstallationSource":true,"hideSystemInstallationSource":true,"excludeTargetInstallationSource":true,"invertActivityLaunchProtection":false,"excludeVoldIsolation":false,"applyTemplates":["莫晨隐藏环境v4.0.0普通版"],"applyPresets":["custom_rom","detector_apps"],"applySettingTemplates":["莫晨环境设置v3.0.0普通版"],"applySettingsPresets":[],"extraAppList":[]},"Han.GJZS":{"useWhitelist":false,"excludeSystemApps":true,"hideInstallationSource":true,"hideSystemInstallationSource":true,"excludeTargetInstallationSource":true,"invertActivityLaunchProtection":false,"excludeVoldIsolation":false,"applyTemplates":["莫晨隐藏环境v4.0.0普通版"],"applyPresets":["custom_rom","detector_apps","root_apps","shizuku_dhizuku","sus_apps","xposed"],"applySettingTemplates":[],"applySettingsPresets":["accessibility","dev_options"],"extraAppList":[]},"com.omarea.vtools":{"useWhitelist":false,"excludeSystemApps":true,"hideInstallationSource":true,"hideSystemInstallationSource":true,"excludeTargetInstallationSource":true,"invertActivityLaunchProtection":false,"excludeVoldIsolation":false,"applyTemplates":["莫晨隐藏环境v4.0.0普通版"],"applyPresets":["root_apps","shizuku_dhizuku","sus_apps","xposed"],"applySettingTemplates":[],"applySettingsPresets":["accessibility","dev_options"],"extraAppList":[]},"com.byxiaorun.detector":{"useWhitelist":false,"excludeSystemApps":true,"hideInstallationSource":true,"hideSystemInstallationSource":true,"excludeTargetInstallationSource":true,"invertActivityLaunchProtection":false,"excludeVoldIsolation":false,"applyTemplates":["莫晨隐藏环境v4.0.0普通版"],"applyPresets":["detector_apps","sus_apps"],"applySettingTemplates":["莫晨环境设置v3.0.0普通版"],"applySettingsPresets":["accessibility","dev_options"],"extraAppList":[]},"org.telegram.messenger.web":{"useWhitelist":false,"excludeSystemApps":true,"hideInstallationSource":true,"hideSystemInstallationSource":true,"excludeTargetInstallationSource":true,"invertActivityLaunchProtection":false,"excludeVoldIsolation":false,"applyTemplates":["莫晨隐藏环境v4.0.0普通版"],"applyPresets":["detector_apps","sus_apps"],"applySettingTemplates":[],"applySettingsPresets":["accessibility","dev_options"],"extraAppList":[]},"wu.Zygisk.Detector":{"useWhitelist":false,"excludeSystemApps":true,"hideInstallationSource":true,"hideSystemInstallationSource":true,"excludeTargetInstallationSource":true,"invertActivityLaunchProtection":false,"excludeVoldIsolation":false,"applyTemplates":["莫晨隐藏环境v4.0.0普通版"],"applyPresets":["detector_apps","sus_apps"],"applySettingTemplates":[],"applySettingsPresets":[],"extraAppList":[]},"com.virb3.trustmealready":{"useWhitelist":false,"excludeSystemApps":true,"hideInstallationSource":true,"hideSystemInstallationSource":true,"excludeTargetInstallationSource":true,"invertActivityLaunchProtection":false,"excludeVoldIsolation":false,"applyTemplates":["莫晨隐藏环境v4.0.0普通版"],"applyPresets":["xposed"],"applySettingTemplates":[],"applySettingsPresets":[],"extraAppList":[]},"com.github.dan.NoStorageRestrict":{"useWhitelist":false,"excludeSystemApps":true,"hideInstallationSource":false,"hideSystemInstallationSource":true,"excludeTargetInstallationSource":true,"invertActivityLaunchProtection":false,"excludeVoldIsolation":false,"applyTemplates":["莫晨隐藏环境v4.0.0普通版"],"applyPresets":["xposed"],"applySettingTemplates":[],"applySettingsPresets":[],"extraAppList":[]},"com.accessibilitymanager":{"useWhitelist":false,"excludeSystemApps":true,"hideInstallationSource":true,"hideSystemInstallationSource":true,"excludeTargetInstallationSource":true,"invertActivityLaunchProtection":false,"excludeVoldIsolation":false,"applyTemplates":["莫晨隐藏环境v4.0.0普通版"],"applyPresets":["root_apps","sus_apps"],"applySettingTemplates":[],"applySettingsPresets":[],"extraAppList":[]},"com.bwnc.zcj":{"useWhitelist":false,"excludeSystemApps":true,"hideInstallationSource":true,"hideSystemInstallationSource":true,"excludeTargetInstallationSource":true,"invertActivityLaunchProtection":false,"excludeVoldIsolation":false,"applyTemplates":["莫晨隐藏环境v4.0.0普通版"],"applyPresets":["sus_apps"],"applySettingTemplates":["莫晨环境设置v3.0.0普通版"],"applySettingsPresets":[],"extraAppList":[]},"com.feilun.main":{"useWhitelist":false,"excludeSystemApps":true,"hideInstallationSource":true,"hideSystemInstallationSource":true,"excludeTargetInstallationSource":true,"invertActivityLaunchProtection":false,"excludeVoldIsolation":false,"applyTemplates":["莫晨隐藏环境v4.0.0普通版"],"applyPresets":["sus_apps"],"applySettingTemplates":["莫晨环境设置v3.0.0普通版"],"applySettingsPresets":[],"extraAppList":[]},"com.hicorenational.antifraud":{"useWhitelist":false,"excludeSystemApps":true,"hideInstallationSource":true,"hideSystemInstallationSource":true,"excludeTargetInstallationSource":true,"invertActivityLaunchProtection":false,"excludeVoldIsolation":false,"applyTemplates":["莫晨隐藏环境v4.0.0普通版"],"applyPresets":["custom_rom"],"applySettingTemplates":[],"applySettingsPresets":["accessibility","dev_options"],"extraAppList":[]},"tmgp.atlas.toolbox":{"useWhitelist":false,"excludeSystemApps":true,"hideInstallationSource":true,"hideSystemInstallationSource":true,"excludeTargetInstallationSource":true,"invertActivityLaunchProtection":false,"excludeVoldIsolation":false,"applyTemplates":["莫晨隐藏环境v4.0.0普通版"],"applyPresets":["root_apps","sus_apps"],"applySettingTemplates":[],"applySettingsPresets":[],"extraAppList":[]},"com.bilibili.studio":{"useWhitelist":false,"excludeSystemApps":true,"hideInstallationSource":true,"hideSystemInstallationSource":true,"excludeTargetInstallationSource":true,"invertActivityLaunchProtection":false,"excludeVoldIsolation":false,"applyTemplates":["莫晨隐藏环境v4.0.0普通版"],"applyPresets":["custom_rom","detector_apps"],"applySettingTemplates":["莫晨环境设置v3.0.0普通版"],"applySettingsPresets":["accessibility","dev_options"],"extraAppList":[]},"com.coloros.alarmclock":{"useWhitelist":false,"excludeSystemApps":true,"hideInstallationSource":true,"hideSystemInstallationSource":true,"excludeTargetInstallationSource":true,"invertActivityLaunchProtection":false,"excludeVoldIsolation":false,"applyTemplates":["莫晨隐藏环境v4.0.0普通版"],"applyPresets":["custom_rom","detector_apps"],"applySettingTemplates":["莫晨环境设置v3.0.0普通版"],"applySettingsPresets":["accessibility","dev_options"],"extraAppList":[]},"com.jingdong.app.mall":{"useWhitelist":false,"excludeSystemApps":true,"hideInstallationSource":true,"hideSystemInstallationSource":true,"excludeTargetInstallationSource":true,"invertActivityLaunchProtection":false,"excludeVoldIsolation":false,"applyTemplates":["莫晨隐藏环境v4.0.0普通版"],"applyPresets":["custom_rom","detector_apps"],"applySettingTemplates":["莫晨环境设置v3.0.0普通版"],"applySettingsPresets":["accessibility","dev_options","input_method"],"extraAppList":[]},"wu.keyChain.test":{"useWhitelist":false,"excludeSystemApps":true,"hideInstallationSource":true,"hideSystemInstallationSource":true,"excludeTargetInstallationSource":true,"invertActivityLaunchProtection":false,"excludeVoldIsolation":false,"applyTemplates":["莫晨隐藏环境v4.0.0普通版"],"applyPresets":["custom_rom","detector_apps"],"applySettingTemplates":["莫晨环境设置v3.0.0普通版"],"applySettingsPresets":["accessibility","dev_options","input_method"],"extraAppList":[]},"com.xunmeng.pinduoduo":{"useWhitelist":false,"excludeSystemApps":true,"hideInstallationSource":true,"hideSystemInstallationSource":true,"excludeTargetInstallationSource":true,"invertActivityLaunchProtection":false,"excludeVoldIsolation":false,"applyTemplates":["莫晨隐藏环境v4.0.0普通版"],"applyPresets":["custom_rom","detector_apps"],"applySettingTemplates":["莫晨环境设置v3.0.0普通版"],"applySettingsPresets":["accessibility","dev_options","input_method"],"extraAppList":[]},"com.studio.duckdetector":{"useWhitelist":false,"excludeSystemApps":true,"hideInstallationSource":true,"hideSystemInstallationSource":true,"excludeTargetInstallationSource":true,"invertActivityLaunchProtection":false,"excludeVoldIsolation":false,"applyTemplates":["莫晨隐藏环境v4.0.0普通版"],"applyPresets":["custom_rom","detector_apps"],"applySettingTemplates":["莫晨环境设置v3.0.0普通版"],"applySettingsPresets":["accessibility","dev_options","input_method"],"extraAppList":[]},"com.fkjc.zcro":{"useWhitelist":false,"excludeSystemApps":true,"hideInstallationSource":true,"hideSystemInstallationSource":true,"excludeTargetInstallationSource":true,"invertActivityLaunchProtection":false,"excludeVoldIsolation":false,"applyTemplates":["莫晨隐藏环境v4.0.0普通版"],"applyPresets":["custom_rom","detector_apps","sus_apps","xposed"],"applySettingTemplates":["莫晨环境设置v3.0.0普通版"],"applySettingsPresets":[],"extraAppList":[]}}}'

echo "$NEW_CONFIG" > "$CONFIG_FILE"
echo "隐藏应用列表配置成功！"


cp -rf /data/adb/modules/most_sky/keybox.xml /data/adb/tricky_store/keybox.xml

echo "keybox更新成功"



#!/bin/bash
PROPS=(
  "ro.boot.flash.locked=1" "ro.boot.verifiedbootstate=green"
  "ro.boot.vbmeta.device_state=locked"
  "ro.secureboot.lockstate=locked" "ro.boot.realmebootstate=green"
  "ro.boot.realme.lockstate=1" "ro.secure=1"
  "ro.adb.secure=1" "ro.build.type=user"
  "ro.build.tags=release-keys" "ro.warranty_bit=0"
  "ro.vendor.warranty_bit=0" "vendor.boot.vbmeta.device_state=locked"
  "vendor.boot.verifiedbootstate=green" "sys.oem_unlock_allowed=0"
)
for prop in "${PROPS[@]}"; do
  NAME=${prop%=*}
  EXPECTED=${prop#*=}
  [ "$(resetprop $NAME)" != "$EXPECTED" ] && resetprop $NAME $EXPECTED
done
if [ -n "$(settings get global hidden_api_policy 2>/dev/null)" ] || \
   [ -n "$(settings get global hidden_api_blacklist_exemptions 2>/dev/null)" ]; then
  settings delete global hidden_api_policy{,_p_apps,_pre_p_apps}
  settings delete global hidden_api_blacklist_exemptions{,s_exe} 2>/dev/null
fi
resetprop -n persist.logd.size{,,.crash,.main} ""
[ "$(getprop ro.crypto.state)" != "encrypted" ] && resetprop ro.crypto.state encrypted
IS_VM=0
[ -x "$(command -v dmidecode)" ] && dmidecode -s system-product-name | grep -qE "VMware|VirtualBox|KVM|QEMU" && IS_VM=1
[[ $(df -h /sdcard 2>/dev/null | awk 'NR==2 {print $3}' | sed 's/G$//') -le 10 ]] && IS_VM=1
[ "$(getenforce)" = "Permissive" ] && [ $IS_VM -eq 0 ] && setenforce 1
for boot_prop in "ro.bootmode" "ro.boot.bootmode" "vendor.boot.bootmode"; do
  [[ "$(resetprop $boot_prop)" = "recovery" ]] && resetprop $boot_prop unknown
done
