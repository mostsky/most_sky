#莫晨一键过春秋环境清理黑名单
# 定义颜色常量
RED='\032[0;31m'
GREEN='\032[0;32m'
YELLOW='\032[1;33m'
BLUE='\032[0;34m'
PURPLE='\032[0;35m'
CYAN='\032[0;36m'
GRAY='\032[0;37m'
NC='\032[0m'

# 标题栏
clear
echo -e "${PURPLE}=============================================${NC}"
echo -e "${CYAN}😘 莫晨隐藏应用配置工具 😘        ${NC}"
echo -e "${PURPLE}=============================================${NC}"
echo -e "${YELLOW}🔧 酷安@莫晨        ${NC}"
echo -e "${PURPLE}=============================================${NC}"
echo -e "${YELLOW}📊主要作用:解决春秋发现风险应用 试图隐藏应用 这两项检测点 需搭配应用隐藏列表使用        ${NC}"
echo -e "${PURPLE}=============================================${NC}"
# 搜索配置目录
echo -e "${BLUE}🔍 正在搜索隐藏应用列表配置目录...${NC}"
hide_dir=$(find "/data/misc" -maxdepth 1 -type d -name "*hide_my_applist*" 2>/dev/null | head -n1)

if [ -n "$hide_dir" ]; then
    target_dir="$hide_dir"
    echo -e "${GREEN}✅ 找到隐藏应用配置目录: ${CYAN}$target_dir${NC}"
else
    echo -e "${RED}❌ 错误: 未找到隐藏应用列表配置目录${NC}"
    exit 1
fi

# 检查配置文件
config_file="${target_dir%/}/config.json"
if [ ! -f "$config_file" ]; then
    echo -e "${RED}❌ 错误: 配置目录下未找到 config.json 文件${NC}"
    exit 1
fi

# 解析配置文件
echo -e "${BLUE}📄 正在解析 config.json 配置文件...${NC}"
content=$(cat "$config_file")

# 提取应用列表
app_lists=$(echo "$content" | grep -o '"appList":\[[^]]*\]')
if [ -z "$app_lists" ]; then
    echo -e "${YELLOW}⚠️  未从配置文件中找到应用列表${NC}"
    exit 0
fi

# 筛选黑名单应用
best_list=""
max_count=0
while IFS= read -r list; do
    context=$(echo "$content" | grep -o '"[^"]*":{[^}]*"isWhitelist":false[^}]*}')
    if echo "$context" | grep -qF "$list"; then
        apps=$(echo "$list" | sed 's/"appList"://;s/\[//;s/\]//' | tr -d '"')
        count=$(echo "$apps" | awk -F, '{print NF}')
        if [ $count -gt $max_count ]; then
            max_count=$count
            best_list="$apps"
        fi
    fi
done <<< "$app_lists"

if [ -z "$best_list" ]; then
    echo -e "${YELLOW}⚠️  未从配置文件中找到黑名单应用${NC}"
    exit 0
fi

# 显示应用统计
echo -e "${GREEN}✅ 成功解析到 ${YELLOW}$max_count${GREEN} 个黑名单应用${NC}"
echo -e "${GRAY}📌 原始包名列表: $best_list${NC}"
sleep 1.5

# 清理准备
echo -e "${PURPLE}=============================================${NC}"
echo -e "${CYAN}        🗑️  开始清理应用外部存储目录        ${NC}"
echo -e "${PURPLE}=============================================${NC}"

clean_dirs=(
    "/storage/emulated/0/Android/data"
    "/storage/emulated/0/Android/media"
    "/storage/emulated/0/Android/obb"
)

total_packages=0
deleted_dirs=0

# 核心清理逻辑
echo "$best_list" | tr ',' '\n' | while IFS= read -r package; do
    clean_pkg=$(echo "$package" | tr -d '[:space:]' | sed 's/[^a-zA-Z0-9._-]//g')    
    [ -z "$clean_pkg" ] && continue    
    total_packages=$((total_packages + 1))
    echo -e "${BLUE}🔄 正在处理: ${CYAN}$clean_pkg${NC}"    
    for base_dir in "${clean_dirs[@]}"; do
        target_path="$base_dir/$clean_pkg"
        if [ -d "$target_path" ]; then
            echo -e "   ${GREEN}✅ 已清理: ${GRAY}$target_path${NC}"
            rm -rf "$target_path" 2>/dev/null
            deleted_dirs=$((deleted_dirs + 1))
        fi
    done
done

# 清理完成总结
echo -e "${PURPLE}=============================================${NC}"
echo -e "${GREEN}🎉 清理任务完成！${NC}"
echo -e "${PURPLE}=============================================${NC}"
